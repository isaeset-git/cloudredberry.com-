<?php if ( ! defined( 'ABSPATH' ) ) { exit; } ?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head><meta charset="<?php bloginfo( 'charset' ); ?>"><meta name="viewport" content="width=device-width, initial-scale=1"><?php wp_head(); ?></head>
<body <?php body_class(); ?>><?php wp_body_open(); ?>
<header class="wrap" style="padding-top:32px;padding-bottom:32px"><a href="<?php echo esc_url( home_url( '/' ) ); ?>">CloudRedBerry</a></header>
<main class="wrap">
<?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
<article <?php post_class(); ?> style="padding:32px 0">
<h1 style="font-size:36px"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h1>
<?php the_content(); wp_link_pages(); ?>
</article>
<?php endwhile; the_posts_pagination(); else : ?>
<p><?php esc_html_e( 'No content found.', 'cloudredberry' ); ?></p>
<?php endif; ?>
</main><?php wp_footer(); ?></body></html>
