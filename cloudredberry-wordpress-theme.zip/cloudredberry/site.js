'use strict';
const nav = document.querySelector('#nav');
const hero = document.querySelector('#top');
const toggle = document.querySelector('.menu-toggle');
function updateNav() { nav.classList.toggle('solid', window.scrollY > hero.offsetHeight - 80); }
window.addEventListener('scroll', updateNav, { passive: true });
updateNav();
function closeMenu() { nav.classList.remove('menu-open'); toggle.setAttribute('aria-expanded', 'false'); }
toggle.addEventListener('click', () => {
  const open = nav.classList.toggle('menu-open');
  toggle.setAttribute('aria-expanded', String(open));
});
nav.querySelectorAll('a').forEach(link => link.addEventListener('click', closeMenu));
document.addEventListener('keydown', event => { if (event.key === 'Escape') closeMenu(); });
const steps = [...document.querySelectorAll('#steps .step')];
function selectStep(index) {
  steps.forEach((step, i) => {
    step.classList.toggle('on', i === index);
    step.setAttribute('aria-pressed', String(i === index));
  });
  document.querySelector('#apFocus').classList.toggle('focus', index === 1);
  const ws = document.querySelector('#ws');
  ws.classList.toggle('drawer-on', index === 1 || index === 2);
  ws.classList.toggle('role-fd', index === 3);
  document.querySelector('#statMoney').classList.toggle('hi', index === 2);
  document.querySelector('#wsAv').textContent = index === 3 ? 'FD' : 'DR';
}
steps.forEach((step, i) => step.addEventListener('click', () => selectStep(i)));
selectStep(0);
