<?php
/** CloudRedBerry marketing homepage. */
if ( ! defined( 'ABSPATH' ) ) { exit; }
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
<meta charset="<?php bloginfo('charset'); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<link rel="icon" type="image/svg+xml" href="<?php echo esc_url( get_theme_file_uri( 'favicon.svg' ) ); ?>" />
<meta name="description" content="Bring schedules, records, payments and people together in a managed CloudRedBerry workspace. Explore demos and compare flat monthly plans." />




<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link" href="#what">Skip to content</a>

<!-- ============================ NAV ============================ -->
<header class="nav" id="nav">
  <div class="wrap in">
    <a class="logo" href="#top"><img class="mark" src="<?php echo esc_url( get_theme_file_uri( 'favicon.svg' ) ); ?>" alt=""> CloudRedBerry</a>
    <nav class="links" id="site-links" aria-label="Site">
      <a href="#what">What you get</a><a href="#examples">Examples</a><a href="#pricing">Pricing</a><a href="#compare">Why switch</a><a href="#how">How it goes live</a>
    </nav>
    <span class="sp"></span>
    <button class="menu-toggle" aria-expanded="false" aria-controls="site-links" aria-label="Toggle navigation">☰</button>
    <a class="btn ghost sm" href="https://demo.cloudredberry.com/" target="_blank" rel="noopener">Open demo ↗</a>
    <a class="btn primary sm" href="#pricing">Explore plans</a>
  </div>
</header>

<!-- ============================ HERO ============================ -->
<div class="stage" id="top">
  <section class="hero wrap">
    <div class="glow"></div>
    <div class="hero-layout"><div class="grid">
      <div class="eyebrow" data-reveal>Managed workspace for one department · Built in Texas</div>
      <h1 data-reveal>Your department, running from one screen.</h1>
      <p class="sub" data-reveal>We take the process you already run — schedule, records, money, stock — and turn it into a private web workspace with a login for every role. Live in four days. One flat monthly price. No servers, no IT hire.</p>
      <div class="ctas" data-reveal>
        <a class="btn primary" href="https://demo.cloudredberry.com/">Explore the demo</a>
        <a class="btn ghost" href="#how">How it goes live</a>
        <a class="btn ghost" href="https://demo.cloudredberry.com/" target="_blank" rel="noopener">Open the working demo →</a>
      </div>
      <div class="proof" data-reveal>
        <span class="avs"><span style="background:#CD2653">D</span><span style="background:#0B7D72">V</span><span style="background:#39424F">L</span></span>
        Explore workflows for dentistry, veterinary care and logistics.
      </div>
    </div>
    
<div class="hero-preview" aria-label="Illustrative CloudRedBerry workspace"><div class="preview-top"><span class="preview-dot"></span> Your workspace <span class="preview-status">All in one place</span></div><div class="preview-body"><div class="eyebrow">Today at a glance</div><h3>A good day starts with a clear view.</h3><div class="preview-metrics"><div><small>Scheduled</small><strong>14</strong></div><div><small>In progress</small><strong>3</strong></div><div><small>Collected</small><strong>$4,180</strong></div></div><div class="preview-row"><span class="preview-icon">▦</span><div><b>Keep the day moving</b><small>Schedules &amp; appointments</small></div><span class="pill p-ok">On track</span></div><div class="preview-row"><span class="preview-icon">▤</span><div><b>The right file, right here</b><small>Records &amp; documents</small></div><span class="pill p-info">Connected</span></div><div class="preview-row"><span class="preview-icon">◎</span><div><b>Everyone knows their next step</b><small>People &amp; permissions</small></div><span class="pill p-ok">Ready</span></div><a class="preview-link" href="https://demo.cloudredberry.com/">Take a look inside <span>↗</span></a></div><div class="preview-bottom">Illustrative workspace · Built around your process</div></div></div>
  </section>

</div>
<div class="stage product-stage">
  <!-- ============================ STORY (pinned) ============================ -->
  <section class="story wrap" id="story">
    <div class="sticky">
      <div class="steps" id="steps">
        <div class="hint">Explore your workspace</div>
        <button class="step on" data-i="0" aria-pressed="true"><span class="n">01</span><span class="tt">Schedule</span>
          <h3>Your day, exactly as the front desk already runs it.</h3><p>Chairs across, time down, one block per visit. Colour means status — nothing else. See appointments and their status at a glance.</p></button>
        <button class="step" aria-pressed="false" data-i="1"><span class="n">02</span><span class="tt">Records</span>
          <h3>Every record one click away — without leaving the board.</h3><p>Click a visit and the file slides in beside it. The board stays where it was. Keep the schedule in view while you review the details.</p></button>
        <button class="step" aria-pressed="false" data-i="2"><span class="n">03</span><span class="tt">Money</span>
          <h3>Money sits next to the visit.</h3><p>What was done becomes what is owed, automatically. Keep billing alongside the clinical record.</p></button>
        <button class="step" aria-pressed="false" data-i="3"><span class="n">04</span><span class="tt">Roles</span>
          <h3>Each login sees only its job.</h3><p>Front desk sees schedule and payments. The dentist sees charts. The director sees everything.</p></button>
        <a class="btn ghost sm openapp" href="https://demo.cloudredberry.com/" target="_blank" rel="noopener">Open the working demo →</a>
      </div>

      <div class="scene">
        <div class="frame" id="frame">
          <div class="ws" id="ws">
            <div class="ws-top">
              <div class="ws-brand"><span class="mk">D</span><span>Dent Austin Group<small>Practice OS · Texas</small></span></div>
              <div class="ws-search"><span>Search patients, procedures, invoices…</span><kbd>⌘K</kbd></div>
              <span class="sp"></span>
              <span class="ws-av" id="wsAv">DR</span>
              <span class="ws-pri">+ New appointment</span>
            </div>
            <div class="ws-body">
              <aside class="ws-side">
                <div class="ws-grp">Today</div>
                <div class="ws-nav on" data-role="dir fd"><i>▦</i>Operatory board<b>14</b></div>
                <div class="ws-nav" data-role="dir fd"><i>◷</i>Check-in queue<b>3</b></div>
                <div class="ws-grp">Patients</div>
                <div class="ws-nav" data-role="dir fd"><i>◍</i>Patients</div>
                <div class="ws-nav" data-role="dir"><i>◆</i>Clinical chart</div>
                <div class="ws-nav" data-role="dir"><i>▤</i>Treatment plans<b>7</b></div>
                <div class="ws-grp">Money</div>
                <div class="ws-nav" data-role="dir fd"><i>▣</i>Cash desk</div>
                <div class="ws-nav" data-role="dir fd"><i>◇</i>Insurance claims<b>5</b></div>
                <div class="ws-grp">Practice</div>
                <div class="ws-nav" data-role="dir"><i>▩</i>Inventory</div>
                <div class="ws-nav" data-role="dir"><i>◎</i>Staff &amp; roles</div>
                <div class="ws-nav" data-role="dir"><i>▥</i>Reports</div>
              </aside>
              <div class="ws-main">
                <div class="ws-title">Operatory board</div>
                <div class="ws-sub">Tuesday 1 September · 4 chairs · Dr. Ruiz, Dr. Osei</div>
                <div class="ws-stats">
                  <div class="ws-stat"><div class="k">Chairs in use</div><div class="v num">3 / 4</div></div>
                  <div class="ws-stat"><div class="k">Checked in</div><div class="v num">3</div></div>
                  <div class="ws-stat"><div class="k">Unsigned notes</div><div class="v num">2</div></div>
                  <div class="ws-stat" id="statMoney"><div class="k">Collected today</div><div class="v num">$4,180<small style="color:var(--green)">+12%</small></div></div>
                </div>
                <div class="ws-grid" id="wsGrid">
                  <div class="hd"></div>
                  <div class="hd">Chair 1<span>Dr. Ruiz</span></div><div class="hd">Chair 2<span>Dr. Ruiz</span></div>
                  <div class="hd">Chair 3<span>Dr. Osei</span></div><div class="hd">Hygiene<span>K. Alvarez</span></div>
                  <div class="t">08:00</div><div><div class="ap ok"><b>Ana Ruiz</b><span>Crown prep · In chair</span></div></div><div></div><div><div class="ap warn"><b>Grace Lee</b><span>Consult · Unsigned</span></div></div><div><div class="ap ok"><b>Sam Whitfield</b><span>Prophy · In chair</span></div></div>
                  <div class="t">08:30</div><div></div><div><div class="ap ok" id="apFocus"><b>Maria Chen</b><span>Root canal · In chair</span></div></div><div></div><div></div>
                  <div class="t">09:00</div><div></div><div></div><div><div class="ap info"><b>Devon Hall</b><span>Extraction · Confirmed</span></div></div><div><div class="ap info"><b>Jonah Park</b><span>Prophy · Checked in</span></div></div>
                  <div class="t">09:30</div><div><div class="ap"><b>Tom Baker</b><span>Exam · Scheduled</span></div></div><div></div><div></div><div></div>
                  <div class="t">10:00</div><div></div><div><div class="ap info"><b>Luis Ortega</b><span>Filling #19 · Confirmed</span></div></div><div></div><div><div class="ap"><b>Nadia Fox</b><span>Sealants · Scheduled</span></div></div>
                  <div class="t">10:30</div><div><div class="ap"><b>Ivy Sandoval</b><span>Build-up · Scheduled</span></div></div><div></div><div><div class="ap"><b>Ruth Aguilar</b><span>Post-op · Scheduled</span></div></div><div></div>
                </div>
              </div>
            </div>
            <aside class="ws-drawer" id="wsDrawer">
              <div><div class="t">Maria Chen · 34 · #A-4182</div><div class="s">Dr. Ruiz · Chair 2 · Delta Dental PPO</div></div>
              <div class="pills"><span class="pill p-ok">In chair</span><span class="pill p-crit">Allergy · penicillin</span><span class="pill p-warn" id="pillBal">Balance $248.00</span></div>
              <div class="tabs"><b>Chart</b><span>Plan</span><span>Account</span><span>Documents</span><span>History</span></div>
              <dl class="kv"><dt>Procedure</dt><dd>D3330 · molar root canal</dd><dt>Tooth</dt><dd>#19</dd><dt>Started</dt><dd>08:34</dd><dt>Insurance</dt><dd>Pre-auth approved</dd></dl>
              <div class="money"><span class="b p hl" id="btnPay">Take payment</span><span class="b">Send claim</span><span class="b">Sign note</span></div>
            </aside>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

<!-- ============================ WHAT YOU GET ============================ -->
<section class="light" id="what">
  <div class="wrap">
    <div class="sec-head">
      <div class="eyebrow" data-reveal>What you buy</div>
      <h2 data-reveal>One license. One department. The whole process, in one place.</h2>
      <p class="sub" data-reveal>Not a bundle of apps. A single workspace built around the steps you already run, with your files moved in and a login for each position.</p>
    </div>
    <div class="tiles" data-reveal-group>
      <div class="tile" data-reveal><div class="ic">▦</div><div class="k">Screens</div><h3>Your process, as screens</h3><p>Schedule, records, money, stock — named the way your team already names them.</p></div>
      <div class="tile" data-reveal><div class="ic">◆</div><div class="k">Files</div><h3>Documents in the step they belong to</h3><p>We move the files in. Findable, permissioned by role, no shared drive.</p></div>
      <div class="tile" data-reveal><div class="ic">◎</div><div class="k">People</div><h3>A login per position</h3><p>Director, front desk, floor, field — each person sees only that job.</p></div>
      <div class="tile" data-reveal><div class="ic">▥</div><div class="k">Devices</div><h3>Laptop, iPad, or phone</h3><p>Same data everywhere. No VPN, no machine in the back room.</p></div>
    </div>
    <div class="integr" data-reveal>
      <span class="lab">Works with the tools your team already uses</span>
      <div class="logos"><span>Microsoft 365</span><span>Google Workspace</span><span>QuickBooks</span><span>Salesforce</span><span>Slack</span><span>Dropbox</span></div>
    </div>
  </div>
</section>

<!-- ============================ EXAMPLES ============================ -->
<section class="light" id="examples">
  <div class="wrap">
    <div class="sec-head">
      <div class="eyebrow" data-reveal>Explore the workspaces</div>
      <h2 data-reveal>Different businesses. One clearer way to work.</h2>
      <p class="sub" data-reveal>Explore three example workspaces. See how the same platform adapts to different teams — then imagine the process <em>you</em> run.</p>
    </div>
    <div class="examples" data-reveal-group>
      <article class="ex" data-reveal>
        <div class="pv"><div class="lab"><span>Operatory · today</span><span style="color:var(--green)">● Demo</span></div>
          <div class="row"><b>08:00 · Chen</b><span class="pill p-ok">In chair</span></div>
          <div class="row"><b>08:30 · Ruiz</b><span class="pill p-info">Checked in</span></div>
          <div class="row"><b>09:00 · Hall</b><span class="pill p-warn">Unsigned</span></div></div>
        <div class="body"><div class="k">01 · Dentistry</div><h3>Dent Austin Group</h3><p>Operatory schedule, clinical chart, patients &amp; CRM, cash desk, inventory.</p><a href="https://demo.cloudredberry.com/#dent/director" target="_blank" rel="noopener">Open this example →</a></div>
      </article>
      <article class="ex" data-reveal>
        <div class="pv"><div class="lab"><span>Waiting room · 3 check-ins</span><span style="color:var(--green)">● Demo</span></div>
          <div class="row"><b>Luna · Sarah M.</b><span class="pill p-ok">Ready</span></div>
          <div class="row"><b>Milo · exam</b><span class="pill p-info">In room</span></div>
          <div class="row"><b>Rex · vaccine</b><span class="pill p-warn">Waiting</span></div></div>
        <div class="body"><div class="k">02 · Veterinary</div><h3>VetFlow · Brazos Animal Hospital</h3><p>Flowboard, signed records, inventory &amp; pharmacy, billing, staff.</p><a href="https://demo.cloudredberry.com/#vet/director" target="_blank" rel="noopener">Open this example →</a></div>
      </article>
      <article class="ex" data-reveal>
        <div class="pv"><div class="lab"><span>Live board · 4 lanes</span><span style="color:var(--green)">● Demo</span></div>
          <div class="row"><b>BYU-48291 · HOU→DAL</b><span class="pill p-info">In transit</span></div>
          <div class="row"><b>BYU-48311 · NOLA</b><span class="pill p-ok">Delivered</span></div>
          <div class="row"><b>BYU-48322 · I-10 hold</b><span class="pill p-crit">Exception</span></div></div>
        <div class="body"><div class="k">03 · Logistics</div><h3>Bayou Logistics</h3><p>Live freight board, tracking, exceptions with an owner, shipper portal.</p><a href="https://demo.cloudredberry.com/#log/director" target="_blank" rel="noopener">Open this example →</a></div>
      </article>
    </div>
    <p class="note" data-reveal>Legal, field operations and mechanical examples are next. Your license maps your own process; the workspaces above are examples.</p>
  </div>
</section>

<!-- ============================ PRICING ============================ -->
<section class="light" id="pricing">
  <div class="wrap">
    <div class="sec-head">
      <div class="eyebrow" data-reveal>Pricing</div>
      <h2 data-reveal>Priced by the work, not the seat.</h2>
      <p class="sub" data-reveal>One flat monthly license for one department. Add people and roles without calling anyone. Hosting, migration and support are inside the number.</p>
    </div>
    <div class="plans" data-reveal-group>
      <div class="plan" data-reveal><div class="nm">Starter</div><div class="pr num">$2,999<small>/mo</small></div><div class="for">One department, up to five workflows. For a team that wants the server room gone this quarter.</div>
        <ul><li>Up to 5 workflows in your process</li><li>Documents &amp; storage, role-based access</li><li>Any device, including iPad</li><li>We map &amp; migrate; email + chat support</li></ul><a class="btn ghost" href="#how">See how setup works</a></div>
      <div class="plan hot" data-reveal><span class="tag">Most teams start here</span><div class="nm">Pro</div><div class="pr num">$4,999<small>/mo</small></div><div class="for">Same department, unlimited workflows and integrations. Replaces a typical in-house IT desk.</div>
        <ul><li>Unlimited workflows &amp; advanced automation</li><li>Custom integrations with tools you keep</li><li>Priority support — phone, email, chat</li><li>Everything in Starter</li></ul><a class="btn primary" href="#how">See how setup works</a></div>
      <div class="plan" data-reveal><div class="nm">Premium</div><div class="pr num">$5,999<small>/mo</small></div><div class="for">For groups that need 24/7 coverage, SLAs and compliance controls in writing.</div>
        <ul><li>24/7 priority support, dedicated line</li><li>Custom SLAs &amp; uptime guarantees</li><li>SSO &amp; compliance controls</li><li>Everything in Pro</li></ul><a class="btn ghost" href="#how">See how setup works</a></div>
    </div>
    <p class="note" data-reveal>No per-seat fees, no per-ticket fees, no hardware. Cancel any time.</p>
  </div>
</section>

<!-- ============================ WHY SWITCH ============================ -->
<section class="light" id="compare">
  <div class="wrap">
    <div class="sec-head">
      <div class="eyebrow" data-reveal>Why switch</div>
      <h2 data-reveal>One license instead of a server room and an IT desk.</h2>
    </div>
    <div class="cmp" data-reveal-group>
      <div class="cmp-col old" data-reveal><div class="cmp-h">The old way — servers &amp; IT</div>
        <ul><li>High capital cost for servers, refreshes and licences</li><li>A full-time IT department just to keep the lights on</li><li>Legacy tools per department that age and slow every year</li><li>Data scattered across drives and duplicated endlessly</li><li>Downtime when a server fails or a key person is out</li><li>Painful, expensive scaling every time you grow</li></ul></div>
      <div class="cmp-col new" data-reveal><div class="cmp-h">CloudRedBerry — one licensed workspace</div>
        <ul><li>One predictable license — no servers, no hardware</li><li>No IT staff to hire; the platform is fully managed</li><li>Always current — the cloud upgrades itself</li><li>Everything in one place — no scattered data</li><li>Any device, anywhere, anytime</li><li>Add employees and roles the same day</li></ul></div>
    </div>
    <div class="nums" data-reveal-group>
      <div class="numt" data-reveal><b class="num">0</b><span>Servers to buy or maintain</span></div>
      <div class="numt" data-reveal><b class="num">1</b><span>Simple license — all included</span></div>
      <div class="numt" data-reveal><b class="num">4<small>days</small></b><span>From mapping call to live</span></div>
      <div class="numt" data-reveal><b class="num">24/7</b><span>Fully managed &amp; supported</span></div>
    </div>
  </div>
</section>

<!-- ============================ HOW IT GOES LIVE ============================ -->
<section class="light" id="how">
  <div class="wrap">
    <div class="sec-head">
      <div class="eyebrow" data-reveal>How it goes live</div>
      <h2 data-reveal>Four days from the way you work today to a running workspace.</h2>
      <p class="sub" data-reveal>We start from your people, files and hand-offs. The old stack stays up until you cut over.</p>
    </div>
    <div class="track" id="track">
      <div class="track-line" id="trackLine"></div>
      <div class="step" data-step><div class="d">Day 0</div><h3>You license one process</h3><p>Starter, Pro or Premium. One department. Users are not billed per seat.</p></div>
      <div class="step" data-step><div class="d">Days 1–2</div><h3>We map how you work</h3><p>People, documents, hand-offs and the systems you already use.</p></div>
      <div class="step" data-step><div class="d">Days 2–4</div><h3>We stand the workspace up</h3><p>Screens, role logins, migrated files. Nothing is switched off yet.</p></div>
      <div class="step" data-step><div class="d">Day 4+</div><h3>Your team runs from one place</h3><p>Any device. The support channel in your plan is already live.</p></div>
    </div>
  </div>
</section>

<!-- ============================ FAQ ============================ -->
<section class="light" id="faq">
  <div class="wrap">
    <div class="sec-head"><div class="eyebrow" data-reveal>Before you license</div><h2 data-reveal>Three questions everyone asks.</h2></div>
    <div class="faq" data-reveal>
      <details><summary>What exactly do I get?</summary><p>A private workspace at your own URL: screens mapped from the process you already run, your files moved in and permissioned, a login for each position, on laptop, iPad or phone. We map it, migrate it and host it. Support is in the monthly fee.</p></details>
      <details><summary>Do I get the dental, vet and logistics apps?</summary><p>No — those belong to other companies and are on this site only as examples. Your license maps <em>your</em> process. If you run a clinic, it will look like the clinic example; if you run freight, like the freight one.</p></details>
      <details><summary>Do I still need servers or IT staff?</summary><p>No. Hosting, updates, uptime and a support channel are part of the license. There is nothing on-premise to babysit.</p></details>
    </div>
  </div>
</section>

<!-- ============================ END CTA ============================ -->
<section class="cta-end">
  <div class="glow"></div>
  <div class="wrap in">
    <div class="eyebrow" data-reveal>Next step</div>
    <h2 data-reveal>Bring the process you already run.</h2>
    <p class="sub" data-reveal>A forty-minute mapping call is enough to tell you what your workspace would contain and which plan fits. No deck, no commitment.</p>
    <div class="ctas" data-reveal style="display:flex;gap:12px;flex-wrap:wrap"><a class="btn primary" href="#pricing">Explore plans</a><a class="btn ghost" href="https://demo.cloudredberry.com/" target="_blank" rel="noopener">Open the working demo</a></div>
  </div>
</section>
<footer><div class="wrap in"><span>© CloudRedBerry · Texas</span><span>Privacy · Terms · Security</span></div></footer>

<div class="toast" id="toast"></div>

<?php wp_footer(); ?>
</body>
</html>
