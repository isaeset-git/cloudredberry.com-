INSTALLATION
In WordPress: Appearance > Themes > Add New Theme > Upload Theme.
Choose cloudredberry-wordpress-theme.zip, install, and preview before activating.

This is a standalone theme built from the supplied static site, not a patch for an existing theme. Its homepage design and copy are in front-page.php; existing posts and pages use index.php. It does not add block-editor controls for homepage sections.

Demo links point to https://demo.cloudredberry.com/ with the supplied industry hash routes. The domain and hash routes have not been verified remotely. Pricing and service promises are retained from the supplied site.

Static layout and interaction checks passed in Chromium. Installation and runtime behavior have not been tested in a running WordPress instance. Back up the active theme before replacing it.
