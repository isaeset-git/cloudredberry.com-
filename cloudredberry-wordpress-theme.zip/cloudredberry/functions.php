<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
function cloudredberry_setup() {
    add_theme_support( 'title-tag' );
    add_theme_support( 'automatic-feed-links' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', array( 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ) );
}
add_action( 'after_setup_theme', 'cloudredberry_setup' );
function cloudredberry_assets() {
    $version = wp_get_theme()->get( 'Version' );
    wp_enqueue_style( 'cloudredberry-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap', array(), null );
    wp_enqueue_style( 'cloudredberry', get_stylesheet_uri(), array(), $version );
    if ( is_front_page() ) {
        wp_enqueue_script( 'cloudredberry', get_theme_file_uri( 'site.js' ), array(), $version, true );
    }
}
add_action( 'wp_enqueue_scripts', 'cloudredberry_assets' );
